"""Assessment framework package for ChemML common infrastructure."""
