"""Configuration package for ChemML common infrastructure."""
