"""Core infrastructure package for ChemML common components."""
